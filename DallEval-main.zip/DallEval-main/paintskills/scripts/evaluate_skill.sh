
python detr/evaluate_skill.py \
    --backbone 'resnet50' \
    --batch_size 20 \
    --num_classes 21 \
    ${@:1}