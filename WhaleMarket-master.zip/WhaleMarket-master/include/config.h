#ifndef _CONFIG_H_
#define _CONFIG_H_

#define MAX_LEN     64
#define MAX_USER    128
#define MAX_GOOD    128
#define MAX_ORDER   256

#define MENU_NUM 8

#define ADMIN_NAME  "admin"
#define ADMIN_PASS  "123456"

#endif
