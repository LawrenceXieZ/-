#ifndef _HINT_H_
#define _HINT_H_

void welcomeMessage();
void successMessage();
void failureMessage();
void illegalMessage();
void loadingMessage();
void exitingMessage();
void invalidMessage();

#endif
